-- Migration: Suppression table help_texts
-- Date: 2026-01-29
-- Raison: Fonctionnalité aide retirée de l'application

DROP TABLE IF EXISTS help_texts;
