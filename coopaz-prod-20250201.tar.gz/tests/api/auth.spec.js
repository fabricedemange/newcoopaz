/**
 * Tests API auth (smoke) : routes publiques sans DB.
 * GET /login doit retourner 200 (page formulaire de connexion).
 */
const request = require("supertest");
const app = require("../../app");

describe("Auth API (smoke)", () => {
  describe("GET /login", () => {
    it("retourne 200 pour la page de connexion", async () => {
      const res = await request(app).get("/login");
      expect(res.status).toBe(200);
    });
  });
});
