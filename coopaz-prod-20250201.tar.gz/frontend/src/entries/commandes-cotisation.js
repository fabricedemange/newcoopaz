import { createApp } from 'vue';
import CotisationHistoriquePage from '@/views/CotisationHistoriquePage.vue';

const app = createApp(CotisationHistoriquePage);
app.mount('#commandes-cotisation-app');
