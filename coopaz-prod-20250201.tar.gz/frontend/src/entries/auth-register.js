import { createApp } from 'vue';
import RegisterPage from '@/views/RegisterPage.vue';

const app = createApp(RegisterPage);
app.mount('#auth-register-app');
